document.getElementById("showSignup").addEventListener("click", function(event) {
    event.preventDefault();
    document.getElementById("loginBox").style.display = "none";
    document.getElementById("signupBox").style.display = "block";
});

document.getElementById("showLogin").addEventListener("click", function(event) {
    event.preventDefault();
    document.getElementById("signupBox").style.display = "none";
    document.getElementById("loginBox").style.display = "block";
});

// ????? ?????? ?? ???????? ?? ??? ????????? ???? ???????
document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();
    var username = document.getElementById("login-username").value;
    var password = document.getElementById("login-password").value;
    var errorMsg = document.getElementById("login-error-msg");

    if (username === "admin" && password === "password123") {
        alert("?? ????? ?????? ?????!");
        errorMsg.style.display = "none";
    } else {
        errorMsg.textContent = "??? ???????? ?? ???? ?????? ??? ????.";
        errorMsg.style.display = "block";
    }
});

document.getElementById("signupForm").addEventListener("submit", function(event) {
    event.preventDefault();
    var username = document.getElementById("signup-username").value;
    var email = document.getElementById("signup-email").value;
    var password = document.getElementById("signup-password").value;
    var confirmPassword = document.getElementById("signup-confirm-password").value;
    var errorMsg = document.getElementById("signup-error-msg");

    if (password !== confirmPassword) {
        errorMsg.textContent = "????? ?????? ??? ???????.";
        errorMsg.style.display = "block";
    } else {
        alert("?? ????? ?????? ?????!");
        errorMsg.style.display = "none";
    }
});
